#!/bin/sh

while true; do echo -ne "`date`\r"; done
