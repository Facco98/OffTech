#!/usr/bin/expect

set timeout 20
spawn telnet localhost  bgpd
expect "Password:"
interact
exit