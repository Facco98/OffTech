#!/bin/sh

sudo nmap -sA 5.6.7.8
