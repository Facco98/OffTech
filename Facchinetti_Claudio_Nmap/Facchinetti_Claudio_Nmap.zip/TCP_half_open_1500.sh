#!/bin/sh
sudo nmap -sS -p 1-1500 5.6.7.8
