#!/bin/sh
sudo nmap -sn -PA 5.6.7.0/24
