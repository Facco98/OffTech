#!/bin/sh

sudo nmap -sn 5.6.7.0/24
