#!/bin/sh

sudo nmap -sX 5.6.7.8
