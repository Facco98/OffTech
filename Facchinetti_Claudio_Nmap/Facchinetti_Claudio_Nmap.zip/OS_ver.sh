#!/bin/sh

sudo nmap -sV -O -A -sC 5.6.7.8
