#!/bin/sh
sudo nmap -sS 5.6.7.8
